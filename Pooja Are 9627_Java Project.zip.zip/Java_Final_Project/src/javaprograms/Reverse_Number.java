package javaprograms;

import java.util.Scanner;

public class Reverse_Number
{

	public static void main(String[] args) 
	{
		Scanner in = new Scanner(System.in);
		System.out.println("Enter a number: ");
		int a,reverse=0;
		a=in.nextInt();
		while(a!=0)
		{
			int remainder = a%10;
			reverse=reverse*10+remainder;
			a=a/10;
		}
		System.out.println(reverse);
	}
}
