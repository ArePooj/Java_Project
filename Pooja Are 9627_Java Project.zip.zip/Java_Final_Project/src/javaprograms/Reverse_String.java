package javaprograms;

import java.util.Scanner;

public class Reverse_String 
{

	public static void main(String[] args)
	{
		System.out.println("Enter a string: ");
		Scanner s = new Scanner(System.in);
		String s1=s.next();
		char c;
		String newstring=" ";
		for(int i=0;i<s1.length();i++)
		{
			c=s1.charAt(i);
			newstring=c+newstring;
		}
		System.out.println(newstring);
		
    }
}