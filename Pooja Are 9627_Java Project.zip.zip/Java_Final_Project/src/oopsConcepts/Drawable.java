package oopsConcepts;

public interface Drawable 
{

}
