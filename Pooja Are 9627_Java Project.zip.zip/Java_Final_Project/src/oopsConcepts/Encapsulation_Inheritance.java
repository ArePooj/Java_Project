package oopsConcepts;

public class Encapsulation_Inheritance 
{
	public static void main(String[] args) 
	{
        // Create a Person object
        Person person = new Person("Pooja", 25);
        System.out.println("Person's name: " + person.getName());
        System.out.println("Person's age: " + person.getAge());

        // Create a Student object
        Student student = new Student("Haasini", 15, "102");
        System.out.println("Student's name: " + student.getName());
        System.out.println("Student's age: " + student.getAge());
        System.out.println("Student's ID: " + student.getStudentId());
    }
}

