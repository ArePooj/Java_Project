package oopsConcepts;

public class Method_OverLoading
{
	void add(int x, int y)
	{
		System.out.println("Add:"+(x+y));
	}
	void add(int x,int y,int z)
	{
		System.out.println("Add:"+(x+y+z));
	}

	public static void main(String[] args)
	{
		Method_OverLoading m=new Method_OverLoading();
		m.add(10,20);
		m.add(10,20,30);

	}

}
